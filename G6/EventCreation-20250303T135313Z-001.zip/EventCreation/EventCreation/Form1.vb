﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Initialize the DateTimePicker to the current date and time
        dtpDateTime.Value = DateTime.Now
        nudHours.Value = 12 ' Default to 12 hours
        nudMinutes.Value = 0 ' Default to 0 minutes
        cmbAMPM.SelectedIndex = 0 ' Default to AM
    End Sub

    Private Sub btnSetDate_Click(sender As Object, e As EventArgs) Handles btnSetDate.Click
        ' Get the selected date from the DateTimePicker
        Dim selectedDate As DateTime = DateTime.Now.Date ' Use today's date

        ' Get the selected time from the NumericUpDown controls
        Dim hours As Integer = CInt(nudHours.Value)
        Dim minutes As Integer = CInt(nudMinutes.Value)

        ' Adjust for AM/PM
        If cmbAMPM.SelectedItem.ToString() = "PM" AndAlso hours < 12 Then
            hours += 12
        ElseIf cmbAMPM.SelectedItem.ToString() = "AM" AndAlso hours = 12 Then
            hours = 0
        End If

        ' Create a DateTime object with the selected date and time
        Dim selectedDateTime As New DateTime(selectedDate.Year, selectedDate.Month, selectedDate.Day, hours, minutes, 0)

        ' Display the selected date and time in a label
        lblSelectedDate.Text = "Selected Date and Time: " & selectedDateTime.ToString("dd/MM/yyyy hh:mm tt")

    End Sub
End Class
