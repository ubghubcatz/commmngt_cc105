﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblSelectedDate = New Label()
        btnSetDate = New Button()
        dtpDateTime = New DateTimePicker()
        nudHours = New NumericUpDown()
        nudMinutes = New NumericUpDown()
        cmbAMPM = New ComboBox()
        CType(nudHours, ComponentModel.ISupportInitialize).BeginInit()
        CType(nudMinutes, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblSelectedDate
        ' 
        lblSelectedDate.AutoSize = True
        lblSelectedDate.Location = New Point(346, 270)
        lblSelectedDate.Name = "lblSelectedDate"
        lblSelectedDate.Size = New Size(53, 20)
        lblSelectedDate.TabIndex = 0
        lblSelectedDate.Text = "Label1"
        ' 
        ' btnSetDate
        ' 
        btnSetDate.Location = New Point(246, 266)
        btnSetDate.Name = "btnSetDate"
        btnSetDate.Size = New Size(94, 29)
        btnSetDate.TabIndex = 2
        btnSetDate.Text = "Button1"
        btnSetDate.UseVisualStyleBackColor = True
        ' 
        ' dtpDateTime
        ' 
        dtpDateTime.CustomFormat = "dd/MM/yyyy hh:mm tt"
        dtpDateTime.Location = New Point(383, 128)
        dtpDateTime.MinDate = New Date(2025, 3, 2, 0, 0, 0, 0)
        dtpDateTime.Name = "dtpDateTime"
        dtpDateTime.Size = New Size(250, 27)
        dtpDateTime.TabIndex = 3
        ' 
        ' nudHours
        ' 
        nudHours.Location = New Point(101, 128)
        nudHours.Maximum = New Decimal(New Integer() {12, 0, 0, 0})
        nudHours.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        nudHours.Name = "nudHours"
        nudHours.Size = New Size(150, 27)
        nudHours.TabIndex = 4
        nudHours.Value = New Decimal(New Integer() {1, 0, 0, 0})
        ' 
        ' nudMinutes
        ' 
        nudMinutes.Location = New Point(101, 158)
        nudMinutes.Maximum = New Decimal(New Integer() {59, 0, 0, 0})
        nudMinutes.Name = "nudMinutes"
        nudMinutes.Size = New Size(150, 27)
        nudMinutes.TabIndex = 5
        ' 
        ' cmbAMPM
        ' 
        cmbAMPM.FormattingEnabled = True
        cmbAMPM.Items.AddRange(New Object() {"AM", "PM"})
        cmbAMPM.Location = New Point(100, 191)
        cmbAMPM.Name = "cmbAMPM"
        cmbAMPM.Size = New Size(151, 28)
        cmbAMPM.TabIndex = 7
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(cmbAMPM)
        Controls.Add(nudMinutes)
        Controls.Add(nudHours)
        Controls.Add(dtpDateTime)
        Controls.Add(btnSetDate)
        Controls.Add(lblSelectedDate)
        Name = "Form1"
        Text = "Form1"
        CType(nudHours, ComponentModel.ISupportInitialize).EndInit()
        CType(nudMinutes, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblSelectedDate As Label
    Friend WithEvents btnSetDate As Button
    Friend WithEvents dtpDateTime As DateTimePicker
    Friend WithEvents nudHours As NumericUpDown
    Friend WithEvents nudMinutes As NumericUpDown
    Friend WithEvents cmbAMPM As ComboBox

End Class
